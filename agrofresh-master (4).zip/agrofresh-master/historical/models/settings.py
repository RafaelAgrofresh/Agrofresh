from core.models import SingletonModel
from django.db import models
from django.utils.translation import gettext_lazy as _


class Settings(SingletonModel):
    show_unack_alarms = models.BooleanField(
        default=True,
        verbose_name = _("Show unacknowledged alarms"),
        help_text= _("Show unacknowledged and active alarms, or only active"),
    )

    class Meta:
        verbose_name = _("Settings")
        verbose_name_plural = _("Settings")
