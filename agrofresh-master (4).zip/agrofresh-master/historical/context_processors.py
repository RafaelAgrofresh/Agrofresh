from django.forms.models import model_to_dict
from .models import Settings


def settings(request):
    context = {
        "settings": model_to_dict(Settings.load()),
    }
    return context