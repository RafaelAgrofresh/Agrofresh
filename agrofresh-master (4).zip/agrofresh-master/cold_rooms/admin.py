from django.contrib import admin
from core.admin import SortableAdminMixin
from . import models


NAMED_FIELDS = ['name', 'description']


@admin.register(models.ColdRoom)
class ColdRoomAdmin(SortableAdminMixin, admin.ModelAdmin):
    exclude = (*SortableAdminMixin.exclude,)
    list_display = (*NAMED_FIELDS, 'endpoint', *SortableAdminMixin.list_display)
    search_fields = (*NAMED_FIELDS,)
